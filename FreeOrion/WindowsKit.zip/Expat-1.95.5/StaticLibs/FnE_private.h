// THIS FILE WILL BE OVERWRITTEN BY DEV-C++!
// DO NOT EDIT!

#ifndef FNE_PRIVATE_H
#define FNE_PRIVATE_H

// VERSION DEFINITIONS
#define VER_STRING	"0.1.1.1"
#define VER_MAJOR	0
#define VER_MINOR	1
#define VER_RELEASE	1
#define VER_BUILD	1
#define COMPANYNAME	""
#define FILEVERSION	""
#define FILEDESCRIPTION	"Developed using the Dev-C++ IDE"
#define INTERNALNAME	""
#define LEGALCOPYRIGHT	""
#define LEGALTRADEMARKS	""
#define ORIGINALFILENAME	""
#define PRODUCTNAME	""
#define PRODUCTVERSION	""

#endif //FNE_PRIVATE_H
